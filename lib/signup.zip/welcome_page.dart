import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class WelcomePage extends StatelessWidget {
  const WelcomePage({Key? key}) : super(key: key);

  Future<String> _getFirstname() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('firstname') ?? 'Member';
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String>(
      future: _getFirstname(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        return Scaffold(
          appBar: AppBar(
            title: const Text('Welcome'),
            backgroundColor: const Color(0xFF002777),
          ),
          body: Center(
            child: Text(
              'Welcome to Slimmers World ${snapshot.data}!',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ),
        );
      },
    );
  }
}
