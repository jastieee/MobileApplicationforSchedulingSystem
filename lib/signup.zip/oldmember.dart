import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'welcome_page.dart';

class OldMemberSearchPage extends StatefulWidget {
  const OldMemberSearchPage({Key? key}) : super(key: key);

  @override
  _OldMemberSearchPageState createState() => _OldMemberSearchPageState();
}

class _OldMemberSearchPageState extends State<OldMemberSearchPage> {
  final TextEditingController _searchController = TextEditingController();
  bool _isLoading = false;
  String? _resultMessage;
  Map<String, String>? _memberInfo;

  Future<void> _searchMember() async {
    final fullName = _searchController.text.trim();

    if (fullName.isEmpty) {
      setState(() {
        _resultMessage = 'Please enter a full name';
        _memberInfo = null;
      });
      return;
    }

    final parts = fullName.split(' ');
    if (parts.length < 2) {
      setState(() {
        _resultMessage = 'Please enter full name with at least first and last name';
        _memberInfo = null;
      });
      return;
    }

    String firstname = parts[0];
    String lastname = parts.last;
    String mi = parts.length == 3 ? parts[1] : '';

    setState(() {
      _isLoading = true;
      _resultMessage = null;
      _memberInfo = null;
    });

    try {
      final response = await http.post(
        Uri.parse('https://membership.ndasphilsinc.com/oldmember.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'firstname': firstname,
          'mi': mi,
          'lastname': lastname,
        }),
      );

      if (response.statusCode != 200) {
        throw Exception('Server error: ${response.statusCode}');
      }

      final jsonResponse = jsonDecode(response.body);
      if (jsonResponse['found'] == true) {
        final m = jsonResponse['member'];
        DateTime birthdate = DateTime.parse(m['birthdate']);
        int age = DateTime.now().year - birthdate.year;
        if (DateTime.now().month < birthdate.month ||
            (DateTime.now().month == birthdate.month && DateTime.now().day < birthdate.day)) {
          age--;
        }

        setState(() {
          _memberInfo = {
            'fullname': '${m['firstname']} ${m['mi']} ${m['lastname']}'.replaceAll(RegExp(r'\s+'), ' ').trim(),
            'branchCode': m['branch_code'],
            'gender': m['gender'],
            'birthdate': m['birthdate'],
            'age': age.toString(),
            'email': m['email'],
            'membershipType': m['membership_type'],
          };
        });
      } else {
        setState(() {
          _resultMessage = 'No member found for "$fullName"';
          _memberInfo = null;
        });
      }
    } catch (e) {
      setState(() {
        _resultMessage = 'Error: $e';
        _memberInfo = null;
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Old Member Search'),
        centerTitle: true,
        backgroundColor: const Color(0xFF002777),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            TextField(
              controller: _searchController,
              textInputAction: TextInputAction.search,
              decoration: const InputDecoration(
                labelText: 'Enter full name (First [MI] Last)',
                border: OutlineInputBorder(),
              ),
              onSubmitted: (_) => _searchMember(),
            ),
            const SizedBox(height: 24),
            if (_isLoading)
              const CircularProgressIndicator(),
            if (_resultMessage != null && !_isLoading)
              Text(
                _resultMessage!,
                style: const TextStyle(fontSize: 16, color: Colors.red),
                textAlign: TextAlign.center,
              ),
            if (_memberInfo != null) ...[
              GestureDetector(
                onTap: () async {
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setBool('isLoggedIn', true);
                  await prefs.setString('firstname', _memberInfo!['fullname']!.split(' ').first);
                  await prefs.setString('membershipType', _memberInfo!['membershipType']!);

                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => const WelcomePage()),
                  );
                },
                child: Card(
                  color: Colors.white,
                  elevation: 4,
                  margin: const EdgeInsets.only(top: 24),
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Full Name: ${_memberInfo!['fullname']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                        Text('Branch Code: ${_memberInfo!['branchCode']}'),
                        Text('Gender: ${_memberInfo!['gender']}'),
                        Text('Birthdate: ${_memberInfo!['birthdate']}'),
                        Text('Age: ${_memberInfo!['age']}'),
                        Text('Email: ${_memberInfo!['email']}'),
                        Text('Membership Type: ${_memberInfo!['membershipType']}'),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'Tap the card above to register and continue.',
                style: TextStyle(fontStyle: FontStyle.italic),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
